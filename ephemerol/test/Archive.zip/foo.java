package com.example.samplewebapp.demo;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import javax.jms.*

import com.example.samplewebapp.domain.service.SampleWebAppService;

public class Foo {



}