$(document).ready(function(){
	
	$("strong").click(function(){
		$(this).css("background-color","green");
	});
	
});